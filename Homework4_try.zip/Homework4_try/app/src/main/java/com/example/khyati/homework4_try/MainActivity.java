package com.example.khyati.homework4_try;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.example.khyati.homework4_try.DataBase.col_acc_time;
import static com.example.khyati.homework4_try.DataBase.col_acc_x;
import static com.example.khyati.homework4_try.DataBase.col_acc_y;
import static com.example.khyati.homework4_try.DataBase.col_acc_z;
import static com.example.khyati.homework4_try.DataBase.col_gps_time;
import static com.example.khyati.homework4_try.DataBase.col_gps_x;
import static com.example.khyati.homework4_try.DataBase.col_gps_y;
import static com.example.khyati.homework4_try.DataBase.col_gyr_time;
import static com.example.khyati.homework4_try.DataBase.col_gyr_x;
import static com.example.khyati.homework4_try.DataBase.col_gyr_y;
import static com.example.khyati.homework4_try.DataBase.col_gyr_z;
import static com.example.khyati.homework4_try.DataBase.col_ori_time;
import static com.example.khyati.homework4_try.DataBase.col_ori_x;
import static com.example.khyati.homework4_try.DataBase.col_ori_y;
import static com.example.khyati.homework4_try.DataBase.col_ori_z;
import static com.example.khyati.homework4_try.DataBase.col_prox_time;
import static com.example.khyati.homework4_try.DataBase.col_prox_value;

//import static com.example.khyati.homework4_try.DataBase.*;

class DataBase extends SQLiteOpenHelper
{
    public SQLiteDatabase database;
    public static final String name = "Homework4_try.db";
    public static final String col_acc_x = "X_Coordinate";
    public static final String col_acc_y = "Y_Coordinate";
    public static final String col_acc_z = "Z_Coordinate";
    public static final String col_ori_x = "X_Coordinate";
    public static final String col_ori_y = "Y_Coordinate";
    public static final String col_ori_z = "Z_Coordinate";
    public static final String col_gyr_x = "X_Coordinate";
    public static final String col_gyr_y = "Y_Coordinate";
    public static final String col_gyr_z = "Z_Coordinate";
    public static final String col_gps_x = "X_Coordinate";
    public static final String col_gps_y = "Y_Coordinate";
    public static final String col_prox_value = "proximity";
    public static final String col_acc_time = "acc_time";
    public static final String col_ori_time = "ori_time";
    public static final String col_gyr_time = "gyr_time";
    public static final String col_gps_time = "gps_time";
    public static final String col_prox_time = "prox_time";


    public DataBase(Context context)
    {
        super(context,name,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.database = db;
        db.execSQL(" CREATE TABLE " + "accelerometer" + " (X_Coordinate TEXT, Y_Coordinate TEXT, Z_Coordinate TEXT, acc_time TEXT) ");
        db.execSQL(" CREATE TABLE " + "orientation" + " (X_Coordinate TEXT, Y_Coordinate TEXT, Z_Coordinate TEXT, ori_time TEXT) ");
        db.execSQL(" CREATE TABLE " + "gyroscope" + " (X_Coordinate TEXT, Y_Coordinate TEXT, Z_Coordinate TEXT, gyr_time TEXT) ");
        db.execSQL(" CREATE TABLE " + "gps" + " (X_Coordinate TEXT, Y_Coordinate TEXT, gps_time TEXT) ");
        db.execSQL(" CREATE TABLE " + "proximity" + " (proximity TEXT, prox_time TEXT) ");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + "accelerometer");
        onCreate(db);

    }
}


public class MainActivity extends AppCompatActivity implements LocationListener,SensorEventListener {
    TextView latitude;
    TextView longitude;
    TextView acc_x;
    TextView acc_y;
    TextView acc_z;
    TextView ori_x;
    TextView ori_y;
    TextView ori_z;
    TextView gyr_x;
    TextView gyr_y;
    TextView gyr_z;
    TextView proximity;
    Button btnstart;
    Button btnstop;
    private SensorManager sensorManager;
    LocationManager locationManager;
    Sensor acc;
    Sensor ori;
    Sensor gyr;
    Sensor gps;
    Sensor pro;
    boolean flag;
    DataBase dbase;

    private float shake,acc_a,acc_b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbase = new DataBase(this);
        btnstart = findViewById(R.id.start_btn);
        btnstop = findViewById(R.id.stop_btn);
        gyr_x = findViewById(R.id.x_gyro);
        gyr_y = findViewById(R.id.y_gyro);
        gyr_z = findViewById(R.id.z_gyro);
        acc_x = findViewById(R.id.x_acc);
        acc_y = findViewById(R.id.y_acc);
        acc_z = findViewById(R.id.z_acc);
        ori_x = findViewById(R.id.x_ori);
        ori_y = findViewById(R.id.y_ori);
        ori_z = findViewById(R.id.z_ori);
        proximity = findViewById(R.id.prox);
        latitude = findViewById(R.id.gps_x);
        longitude = findViewById(R.id.gps_y);

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;
        float shake_detect;
        if(sensor.getType()==Sensor.TYPE_ACCELEROMETER)
        {
            String acc_x_value = String.valueOf(event.values[0]);
            String acc_y_value = String.valueOf(event.values[1]);
            String acc_z_value = String.valueOf(event.values[2]);
            acc_x.setText(acc_x_value);
            acc_y.setText(acc_y_value);
            acc_z.setText(acc_z_value);
            SQLiteDatabase sqLiteDatabase = dbase.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(col_acc_x,acc_x_value);
            contentValues.put(col_acc_y,acc_y_value);
            contentValues.put(col_acc_z,acc_z_value);
            contentValues.put(col_acc_time, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
            sqLiteDatabase.insert("accelerometer",null,contentValues);
            acc_a = acc_b;
            acc_b = (float) Math.sqrt((double) (event.values[0]*event.values[0]+(event.values[1]*event.values[1])+(event.values[2]*event.values[2])));
            shake_detect = acc_b - acc_a;
            shake = shake*0.9f + shake_detect;
            if(shake > 11)
            {
                Toast.makeText(MainActivity.this,"SHAKE DETECTION",Toast.LENGTH_SHORT).show();

            }
        }
        if(sensor.getType()==Sensor.TYPE_ORIENTATION)
        {
            String ori_x_value = String.valueOf(event.values[1]);
            String ori_y_value = String.valueOf(event.values[2]);
            String ori_z_value = String.valueOf(event.values[0]);
            ori_x.setText(ori_x_value);
            ori_y.setText(ori_y_value);
            ori_z.setText(ori_z_value);
            SQLiteDatabase sqLiteDatabase = dbase.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(col_ori_x,ori_x_value);
            contentValues.put(col_ori_y,ori_y_value);
            contentValues.put(col_ori_z,ori_z_value);
            contentValues.put(col_ori_time, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
            sqLiteDatabase.insert("orientation",null,contentValues);



        }
        if(sensor.getType()==Sensor.TYPE_GYROSCOPE)
        {
            String gyr_x_value = String.valueOf(event.values[0]);
            String gyr_y_value = String.valueOf(event.values[1]);
            String gyr_z_value = String.valueOf(event.values[2]);
            gyr_x.setText(gyr_x_value);
            gyr_y.setText(gyr_y_value);
            gyr_z.setText(gyr_z_value);
            SQLiteDatabase sqLiteDatabase = dbase.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(col_gyr_x,gyr_x_value);
            contentValues.put(col_gyr_y,gyr_y_value);
            contentValues.put(col_gyr_z,gyr_z_value);
            contentValues.put(col_gyr_time, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
            sqLiteDatabase.insert("gyroscope",null,contentValues);

        }
        if(sensor.getType()==Sensor.TYPE_PROXIMITY)
        {
            String prox_value = String.valueOf(event.values[0]);
            proximity.setText(prox_value);
            SQLiteDatabase sqLiteDatabase = dbase.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(col_prox_value,prox_value);
            contentValues.put(col_prox_time, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
            sqLiteDatabase.insert("proximity",null,contentValues);
        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onLocationChanged(Location location) {

        String lat_value = String.valueOf(location.getLatitude());
        latitude.setText(lat_value);
        String long_value = String .valueOf(location.getLongitude());
        longitude.setText(long_value);
        SQLiteDatabase sqLiteDatabase = dbase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_gps_x,lat_value);
        contentValues.put(col_gps_y,long_value);
        contentValues.put(col_gps_time, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        sqLiteDatabase.insert("gps",null,contentValues);




    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
    public void Startbtn(View view)
    {
        btnstart.setEnabled(false);
        btnstop.setEnabled(true);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Log.d("Homework-4","Acc sensor activate");
        acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(acc == null)
        {
           NotAcc(acc_x,acc_y,acc_z);

        }
        else
        {
            sensorManager.registerListener(MainActivity.this,acc,SensorManager.SENSOR_DELAY_NORMAL);
            flag = false;

        }
        acc_b = sensorManager.GRAVITY_EARTH;
        acc_a = sensorManager.GRAVITY_EARTH;
        shake = 0.00f;
        ori = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        if(ori ==null)
        {
            NotOri(ori_x,ori_y,ori_z);
        }
        else
        {
            sensorManager.registerListener(MainActivity.this,ori, SensorManager.SENSOR_DELAY_NORMAL);
        }
        gyr = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if(gyr == null)
        {
            NotGyr(gyr_x,gyr_y,gyr_z);
        }

        else
        {

            sensorManager.registerListener(MainActivity.this,gyr,SensorManager.SENSOR_DELAY_NORMAL);
        }

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            Log.d("Homework-4","Acc sensor activate");
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        }

        boolean isGPS = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (isGPS) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000,10,MainActivity.this);
        }

        pro = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        if(pro == null)
        {
            Toast.makeText(MainActivity.this,"NOT SUPPORTED : PROXIMITY",Toast.LENGTH_SHORT).show();
            proximity.setText("NA");
        }
        else
        {
            sensorManager.registerListener(MainActivity.this,pro,SensorManager.SENSOR_DELAY_NORMAL);
        }


    }

    public void NotAcc(TextView acc_x, TextView acc_y, TextView acc_z)
    {
        Toast.makeText(MainActivity.this,"NOT SUPPORTED : ACCELEROMETER",Toast.LENGTH_SHORT).show();
        acc_x.setText("NA");
        acc_y.setText("NA");
        acc_z.setText("NA");
    }
    public void NotOri(TextView ori_x, TextView ori_y, TextView ori_z)
    {
        Toast.makeText(MainActivity.this,"NOT SUPPORTED : ORIENTATION",Toast.LENGTH_SHORT).show();
        ori_x.setText("NA");
        ori_y.setText("NA");
        ori_z.setText("NA");
    }
    public void NotGyr(TextView gyr_x, TextView gyr_y, TextView gyr_z)
    {
        Toast.makeText(MainActivity.this,"NOT SUPPORTED : GYROSCOPE",Toast.LENGTH_SHORT).show();
        gyr_x.setText("NA");
        gyr_y.setText("NA");
        gyr_z.setText("NA");
    }


    public void Stopbtn(View view)
    {
        btnstart.setEnabled(true);
        btnstop.setEnabled(false);
        sensorManager.unregisterListener(MainActivity.this);
        SetBack();


    }
    public void SetBack()
    {
        acc_x.setText("X_Coordinate");
        acc_y.setText("Y_Coordinate");
        acc_z.setText("Z_Coordinate");
        gyr_x.setText("X_Coordinate");
        gyr_y.setText("Y_Coordinate");
        gyr_z.setText("Z_Coordinate");
        ori_x.setText("X_Coordinate");
        ori_y.setText("Y_Coordinate");
        ori_z.setText("Z_Coordinate");
        latitude.setText("X_Coordinate");
        longitude.setText("Y_Coordinate");
        proximity.setText("Value");

    }


}
