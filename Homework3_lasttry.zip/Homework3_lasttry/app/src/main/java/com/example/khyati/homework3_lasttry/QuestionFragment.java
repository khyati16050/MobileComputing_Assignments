package com.example.khyati.homework3_lasttry;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuestionFragment extends AppCompatActivity {


    RadioGroup rg;
    RadioButton rbt;
    RadioButton rbf;
    RadioButton generalrb;
    SQLiteDatabase database;
    SQLiteOpenHelper helper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_question);
        getIncomingIntent();
    }

    private void getIncomingIntent(){

            String Q_number = getIntent().getStringExtra("QuestionNumber");
            String Q_full = getIntent().getStringExtra("QuestionFull");
            set(Q_number,Q_full);

    }

    private void set(String Q_number, String Q_full)
    {
        TextView num = findViewById(R.id.display_num);
        num.setText(Q_number);
        TextView ques = findViewById(R.id.display_question);
        ques.setText(Q_full);
    }

    public void savebutton(View view)
    {
        rg = (RadioGroup) findViewById(R.id.radioGroup);
        rbt = (RadioButton)findViewById(R.id.radioButton_true);
        rbf = (RadioButton)findViewById(R.id.radioButton_false2);
        int id = rg.getCheckedRadioButtonId();
        generalrb = (RadioButton)findViewById(id);
        String select_text = generalrb.getText().toString();
        helper = new DataBase(this);
        database = helper.getWritableDatabase();
        database = helper.getReadableDatabase();

        Toast.makeText(this, "SAVED ANSWER IS "+ select_text, Toast.LENGTH_SHORT).show();

    }


}
