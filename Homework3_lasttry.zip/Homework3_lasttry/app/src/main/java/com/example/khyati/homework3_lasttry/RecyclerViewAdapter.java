package com.example.khyati.homework3_lasttry;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private ArrayList<String> question_number_list = new ArrayList<>();
    private ArrayList<String> question_list = new ArrayList<>();
    private Context mcontext;

    public RecyclerViewAdapter(Context mcontext, ArrayList<String> question_number_list, ArrayList<String> question_list) {
        this.question_number_list = question_number_list;
        this.question_list = question_list;
        this.mcontext = mcontext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int position) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_listitem,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder  ;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.number.setText(question_number_list.get(position));
        holder.question.setText(question_list.get(position));

        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Toast.makeText(mcontext, question_list.get(position), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(mcontext, QuestionFragment.class);
                intent.putExtra("QuestionNumber",question_number_list.get(position));
                intent.putExtra("QuestionFull",question_list.get(position));
                mcontext.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return question_number_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView number;
        TextView question;
        ConstraintLayout parentLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.qnumber_txt);
            question = itemView.findViewById(R.id.question_txt);
            parentLayout = itemView.findViewById(R.id.parent_layout);

        }
    }
}
