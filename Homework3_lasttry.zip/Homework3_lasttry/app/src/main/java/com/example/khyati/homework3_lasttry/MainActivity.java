package com.example.khyati.homework3_lasttry;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private ArrayList<String> mNumbers = new ArrayList<>();
    private ArrayList<String> mQuestions = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initAddQuestions();


    }

    private void initAddQuestions() {

        mNumbers.add("1");
        mNumbers.add("2");
        mNumbers.add("3");
        mNumbers.add("4");
        mNumbers.add("5");
        mNumbers.add("6");
        mNumbers.add("7");
        mNumbers.add("8");
        mNumbers.add("9");
        mNumbers.add("10");
        mNumbers.add("11");
        mNumbers.add("12");
        mNumbers.add("13");
        mNumbers.add("14");
        mNumbers.add("15");
        mNumbers.add("16");
        mNumbers.add("17");
        mNumbers.add("18");
        mNumbers.add("19");
        mNumbers.add("20");
        mNumbers.add("21");
        mNumbers.add("22");
        mNumbers.add("23");
        mNumbers.add("24");
        mNumbers.add("25");
        mNumbers.add("26");
        mNumbers.add("27");
        mNumbers.add("28");
        mNumbers.add("29");
        mNumbers.add("30");
        mQuestions.add(" As far as has ever been reported, no-one has ever seen an ostrich bury its head in the sand");
        mQuestions.add("Approximately one quarter of human bones are in the feet.");
        mQuestions.add("Popeye’s nephews were called Peepeye, Poopeye, Pipeye and Pupeye.");
        mQuestions.add("In ancient Rome,vomitorium was available for diners to purge food in during meals.");
        mQuestions.add("The average person will shed 10 pounds of skin during their lifetime.");
        mQuestions.add("Sneezes regularly exceed 100 m.p.h.");
        mQuestions.add("A slug’s blood is green.");
        mQuestions.add("The Great Wall Of China is visible from the moon.");
        mQuestions.add("Virtually all Las Vegas gambling casinos ensure that they have no clocks.");
        mQuestions.add("The total surface area of two human lungs have a surface area of approximately 70 square metres.");
        mQuestions.add("Electrons are larger than molecules.");
        mQuestions.add("The Atlantic Ocean is the biggest ocean on Earth.");
        mQuestions.add("The chemical make up food often changes when you cook it.");
        mQuestions.add("Sharks are mammals.");
        mQuestions.add("The human body has four lungs.");
        mQuestions.add("Atoms are most stable when their outer shells are full");
        mQuestions.add("Filtration separates mixtures based upon their particle size.");
        mQuestions.add("Venus is the closest planet to the Sun.");
        mQuestions.add("Conductors have low resistance.");
        mQuestions.add("Molecules can have atoms from more than one chemical element.");
        mQuestions.add("Water is an example of a chemical element.");
        mQuestions.add("The study of plants is known as botany.");
        mQuestions.add("Mount Kilimanjaro is the tallest mountain in the world.");
        mQuestions.add("Floatation separates mixtures based on density.");
        mQuestions.add("Herbivores eat meat.");
        mQuestions.add("Atomic bombs work by atomic fission.");
        mQuestions.add("Molecules are chemically bonded.");
        mQuestions.add("Spiders have six legs");
        mQuestions.add("Kelvin is a measure of temperature");
        mQuestions.add("The human skeleton is made up of less than 100 bones.");

        initRecyclerView();

    }

    private void initRecyclerView(){
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this,mNumbers,mQuestions);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


}
