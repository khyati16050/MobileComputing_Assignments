package com.example.khyati.homework3_lasttry;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBase extends SQLiteOpenHelper {

    public SQLiteDatabase database;
    public static final String dbname ="homework3_jaimatadi.db";
    public static final String table ="homework3_table";
    public static final String col_1 ="id";
    public static final String col_2 ="question_num";
    public static final String col_3 ="question";
    public static final String col_4 ="answer";



    public DataBase(Context context)
    {
        super(context,dbname,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.database = db;
        db.execSQL(" CREATE TABLE "+table+ " (id INTEGER PRIMARY KEY AUTOINCREMENT, question_num TEXT, question TEXT, answer TEXT) ");
        ContentValues contentValues1 = new ContentValues();
        ContentValues contentValues2 = new ContentValues();
        ContentValues contentValues3 = new ContentValues();
        ContentValues contentValues4 = new ContentValues();
        ContentValues contentValues5 = new ContentValues();
        ContentValues contentValues6 = new ContentValues();
        ContentValues contentValues7 = new ContentValues();
        ContentValues contentValues8 = new ContentValues();
        ContentValues contentValues9 = new ContentValues();
        ContentValues contentValues10 = new ContentValues();
        ContentValues contentValues11 = new ContentValues();
        ContentValues contentValues12 = new ContentValues();
        ContentValues contentValues13 = new ContentValues();
        ContentValues contentValues14 = new ContentValues();
        ContentValues contentValues15 = new ContentValues();
        ContentValues contentValues16 = new ContentValues();
        ContentValues contentValues17 = new ContentValues();
        ContentValues contentValues18 = new ContentValues();
        ContentValues contentValues19 = new ContentValues();
        ContentValues contentValues20 = new ContentValues();
        ContentValues contentValues21 = new ContentValues();
        ContentValues contentValues22 = new ContentValues();
        ContentValues contentValues23 = new ContentValues();
        ContentValues contentValues24 = new ContentValues();
        ContentValues contentValues25 = new ContentValues();
        ContentValues contentValues26 = new ContentValues();
        ContentValues contentValues27 = new ContentValues();
        ContentValues contentValues28 = new ContentValues();
        ContentValues contentValues29 = new ContentValues();
        ContentValues contentValues30 = new ContentValues();

        contentValues1.put(col_2,"1");
        contentValues2.put(col_2,"2");
        contentValues3.put(col_2,"3");
        contentValues4.put(col_2,"4");
        contentValues5.put(col_2,"5");
        contentValues6.put(col_2,"6");
        contentValues7.put(col_2,"7");
        contentValues8.put(col_2,"8");
        contentValues9.put(col_2,"9");
        contentValues10.put(col_2,"10");
        contentValues11.put(col_2,"11");
        contentValues12.put(col_2,"12");
        contentValues13.put(col_2,"13");
        contentValues14.put(col_2,"14");
        contentValues15.put(col_2,"15");
        contentValues16.put(col_2,"16");
        contentValues17.put(col_2,"17");
        contentValues18.put(col_2,"18");
        contentValues19.put(col_2,"19");
        contentValues20.put(col_2,"20");
        contentValues21.put(col_2,"21");
        contentValues22.put(col_2,"22");
        contentValues23.put(col_2,"23");
        contentValues24.put(col_2,"24");
        contentValues25.put(col_2,"25");
        contentValues26.put(col_2,"26");
        contentValues27.put(col_2,"27");
        contentValues28.put(col_2,"28");
        contentValues29.put(col_2,"29");
        contentValues30.put(col_2,"30");
        contentValues1.put(col_3," As far as has ever been reported, no-one has ever seen an ostrich bury its head in the sand");
        contentValues2.put(col_3,"Approximately one quarter of human bones are in the feet.");
        contentValues3.put(col_3,"Popeye’s nephews were called Peepeye, Poopeye, Pipeye and Pupeye.");
        contentValues4.put(col_3,"In ancient Rome,vomitorium was available for diners to purge food in during meals.");
        contentValues5.put(col_3,"The average person will shed 10 pounds of skin during their lifetime.");
        contentValues6.put(col_3,"Sneezes regularly exceed 100 m.p.h.");
        contentValues7.put(col_3,"A slug’s blood is green.");
        contentValues8.put(col_3,"The Great Wall Of China is visible from the moon.");
        contentValues9.put(col_3,"Virtually all Las Vegas gambling casinos ensure that they have no clocks.");
        contentValues10.put(col_3,"The total surface area of two human lungs have a surface area of approximately 70 square metres.");
        contentValues11.put(col_3,"Electrons are larger than molecules.");
        contentValues12.put(col_3,"The Atlantic Ocean is the biggest ocean on Earth.");
        contentValues13.put(col_3,"The chemical make up food often changes when you cook it.");
        contentValues14.put(col_3,"Sharks are mammals.");
        contentValues15.put(col_3,"The human body has four lungs.");
        contentValues16.put(col_3,"Atoms are most stable when their outer shells are full");
        contentValues17.put(col_3,"Filtration separates mixtures based upon their particle size.");
        contentValues18.put(col_3,"Venus is the closest planet to the Sun.");
        contentValues19.put(col_3,"Conductors have low resistance.");
        contentValues20.put(col_3,"Molecules can have atoms from more than one chemical element.");
        contentValues21.put(col_3,"Water is an example of a chemical element.");
        contentValues22.put(col_3,"The study of plants is known as botany.");
        contentValues23.put(col_3,"Mount Kilimanjaro is the tallest mountain in the world.");
        contentValues24.put(col_3,"Floatation separates mixtures based on density.");
        contentValues25.put(col_3,"Herbivores eat meat.");
        contentValues26.put(col_3,"Atomic bombs work by atomic fission.");
        contentValues27.put(col_3,"Molecules are chemically bonded.");
        contentValues28.put(col_3,"Spiders have six legs");
        contentValues29.put(col_3,"Kelvin is a measure of temperature");
        contentValues30.put(col_3,"The human skeleton is made up of less than 100 bones.");

        db.insert(table,col_2,contentValues1);
        db.insert(table,col_2,contentValues2);
        db.insert(table,col_2,contentValues3);
        db.insert(table,col_2,contentValues4);
        db.insert(table,col_2,contentValues5);
        db.insert(table,col_2,contentValues6);
        db.insert(table,col_2,contentValues7);
        db.insert(table,col_2,contentValues8);
        db.insert(table,col_2,contentValues9);
        db.insert(table,col_2,contentValues10);
        db.insert(table,col_2,contentValues11);
        db.insert(table,col_2,contentValues12);
        db.insert(table,col_2,contentValues13);
        db.insert(table,col_2,contentValues14);
        db.insert(table,col_2,contentValues15);
        db.insert(table,col_2,contentValues16);
        db.insert(table,col_2,contentValues17);
        db.insert(table,col_2,contentValues18);
        db.insert(table,col_2,contentValues19);
        db.insert(table,col_2,contentValues20);
        db.insert(table,col_2,contentValues21);
        db.insert(table,col_2,contentValues22);
        db.insert(table,col_2,contentValues23);
        db.insert(table,col_2,contentValues24);
        db.insert(table,col_2,contentValues25);
        db.insert(table,col_2,contentValues26);
        db.insert(table,col_2,contentValues27);
        db.insert(table,col_2,contentValues28);
        db.insert(table,col_2,contentValues29);
        db.insert(table,col_2,contentValues30);
        db.insert(table,col_3,contentValues1);
        db.insert(table,col_3,contentValues2);
        db.insert(table,col_3,contentValues3);
        db.insert(table,col_3,contentValues4);
        db.insert(table,col_3,contentValues5);
        db.insert(table,col_3,contentValues6);
        db.insert(table,col_3,contentValues7);
        db.insert(table,col_3,contentValues8);
        db.insert(table,col_3,contentValues9);
        db.insert(table,col_3,contentValues10);
        db.insert(table,col_3,contentValues11);
        db.insert(table,col_3,contentValues12);
        db.insert(table,col_3,contentValues13);
        db.insert(table,col_3,contentValues14);
        db.insert(table,col_3,contentValues15);
        db.insert(table,col_3,contentValues16);
        db.insert(table,col_3,contentValues17);
        db.insert(table,col_3,contentValues18);
        db.insert(table,col_3,contentValues19);
        db.insert(table,col_3,contentValues20);
        db.insert(table,col_3,contentValues21);
        db.insert(table,col_3,contentValues22);
        db.insert(table,col_3,contentValues23);
        db.insert(table,col_3,contentValues24);
        db.insert(table,col_3,contentValues25);
        db.insert(table,col_3,contentValues26);
        db.insert(table,col_3,contentValues27);
        db.insert(table,col_3,contentValues28);
        db.insert(table,col_3,contentValues29);
        db.insert(table,col_3,contentValues30);





    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(database);

    }
}
