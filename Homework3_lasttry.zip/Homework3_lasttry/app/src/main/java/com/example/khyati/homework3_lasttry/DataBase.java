package com.example.khyati.homework3_lasttry;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBase extends SQLiteOpenHelper {

    public SQLiteDatabase database;
    public static final String dbname ="homework3.db";
    public static final String table ="homework3_table";
    public static final String col_1 ="id";
    public static final String col_2 ="question_num";
    public static final String col_3 ="question";
    public static final String col_4 ="answer";


    public DataBase(Context context)
    {
        super(context,dbname,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(col_2,"1");
        this.database = database;
        database.execSQL(" CREATE TABLE "+table+ " (id INTEGER PRIMARY KEY AUTOINCREMENT, question_num TEXT, question TEXT, answer TEXT) ");
        database.insert(table,col_2,contentValues);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(database);

    }
}
